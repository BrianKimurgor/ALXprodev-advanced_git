Objective: Understand and initialize a GitFlow workflow

Instructions:

Install git-flow if not already installed. Steps here

Create an empty repository ALXprodev-advanced_git

Clone your repository to have it available locally.

Initialize Git Flow within the repository using default settings i.e git-flow init [-d]