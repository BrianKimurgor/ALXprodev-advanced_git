feature coming soon
data requirements: email, firstName, lastName, profilePic
